
# O projeto utiliza apenas bibliotecas padrão do Python.
# Tkinter precisa estar disponível na instalação do Python.
