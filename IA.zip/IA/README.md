
# DevChat AI

Chatbot desktop desenvolvido em Python com Tkinter para uma
atividade acadêmica de desenvolvimento de interfaces gráficas.

## Sobre o projeto

O DevChat AI é um chatbot com interface gráfica que simula um
assistente de inteligência artificial especializado em Tecnologia
da Informação.

O sistema possui autenticação local, conversas com respostas
automáticas, alternância de temas e identificação das mensagens.

## Funcionalidades

- Tela de login com validação de usuário e senha.
- Interface gráfica desktop.
- Modo escuro e modo claro.
- Mensagens identificadas por nome e ícone.
- Histórico de conversa com rolagem.
- Botões para enviar mensagens e limpar a conversa.
- Respostas automáticas sobre assuntos de TI.
- Atraso simulado nas respostas do chatbot.

## Tecnologias utilizadas

- Python 3
- Tkinter
- Biblioteca random
- Biblioteca padrão tkinter

## Estrutura do projeto

```text
DevChat-AI/
├── main.py
├── chatbot.py
├── requirements.txt
├── README.md
└── screenshots/
    ├── login.png
    └── chat.png
```

## ▶Como executar

1. Instale o Python 3.
2. Clone o repositório ou baixe os arquivos.
3. Abra a pasta no VS Code.
4. Execute no terminal:

   ```bash
   python main.py
   ```

## Acesso de demonstração

- Usuário: aluno
- Senha: 1234

As credenciais são definidas diretamente no código para fins
didáticos.

## Capturas de tela

### Tela de login

![Tela de login](screenshots/login.png)

### Tela principal do chat

![Tela do chat](screenshots/chat.png)

## Observação acadêmica

As respostas são simuladas localmente por regras condicionais.
O projeto não utiliza uma API externa nem um modelo de IA real.

## 👨‍💻 Objetivo

Praticar interfaces gráficas, validação de login, organização
do código Python e conceitos de experiência do usuário.
