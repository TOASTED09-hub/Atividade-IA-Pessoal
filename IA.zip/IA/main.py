
import tkinter as tk
from tkinter import messagebox
from chatbot import responder

# Credenciais de acesso da atividade
USUARIO_CORRETO = "aluno"
SENHA_CORRETA = "1234"

NOME_USUARIO = "Aluno"
NOME_BOT = "DevChat AI"

class DevChatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DevChat AI")
        self.root.geometry("900x650")
        self.root.minsize(600, 450)

        self.tema_escuro = True
        self.historico = []

        self.login()

    def cores(self):
        if self.tema_escuro:
            return {
                "fundo": "#171923",
                "painel": "#202433",
                "texto": "#F1F5F9",
                "secundario": "#AAB4C5",
                "usuario": "#294D70",
                "bot": "#292F40",
                "botao": "#3978E8",
                "entrada": "#252B3A"
            }
        return {
            "fundo": "#F2F5FA",
            "painel": "#FFFFFF",
            "texto": "#202938",
            "secundario": "#657187",
            "usuario": "#D8EAFE",
            "bot": "#E7EAF0",
            "botao": "#2563EB",
            "entrada": "#FFFFFF"
        }

    def limpar_tela(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def login(self):
        self.limpar_tela()
        c = self.cores()
        self.root.configure(bg=c["fundo"])

        quadro = tk.Frame(self.root, bg=c["painel"], padx=35, pady=30)
        quadro.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(
            quadro, text="🤖 DevChat AI",
            font=("Segoe UI", 24, "bold"),
            bg=c["painel"], fg=c["texto"]
        ).pack(pady=(0, 8))

        tk.Label(
            quadro, text="Seu assistente de tecnologia",
            font=("Segoe UI", 11),
            bg=c["painel"], fg=c["secundario"]
        ).pack(pady=(0, 25))

        tk.Label(
            quadro, text="Usuário",
            bg=c["painel"], fg=c["texto"],
            anchor="w"
        ).pack(fill="x")

        self.campo_usuario = tk.Entry(
            quadro, font=("Segoe UI", 12), width=28
        )
        self.campo_usuario.pack(pady=(5, 15), ipady=6)

        tk.Label(
            quadro, text="Senha",
            bg=c["painel"], fg=c["texto"],
            anchor="w"
        ).pack(fill="x")

        self.campo_senha = tk.Entry(
            quadro, font=("Segoe UI", 12),
            width=28, show="*"
        )
        self.campo_senha.pack(pady=(5, 20), ipady=6)

        tk.Button(
            quadro, text="Entrar",
            font=("Segoe UI", 11, "bold"),
            bg=c["botao"], fg="white",
            activebackground=c["botao"],
            activeforeground="white",
            relief="flat", cursor="hand2",
            command=self.validar_login
        ).pack(fill="x", ipady=7)

        tk.Label(
            quadro, text="Acesso de demonstração: aluno / 1234",
            bg=c["painel"], fg=c["secundario"],
            font=("Segoe UI", 9)
        ).pack(pady=(18, 0))

        self.campo_usuario.focus_set()
        self.root.bind("<Return>", self.entrar_tecla)

    def entrar_tecla(self, event):
        if hasattr(self, "campo_usuario"):
            self.validar_login()

    def validar_login(self):
        usuario = self.campo_usuario.get().strip()
        senha = self.campo_senha.get()

        if usuario == USUARIO_CORRETO and senha == SENHA_CORRETA:
            self.root.unbind("<Return>")
            self.tela_chat()
        else:
            messagebox.showerror(
                "Erro de login",
                "Usuário ou senha incorretos!"
            )

    def tela_chat(self):
        self.limpar_tela()
        c = self.cores()
        self.root.configure(bg=c["fundo"])

        # Cabeçalho
        topo = tk.Frame(self.root, bg=c["painel"], padx=18, pady=12)
        topo.pack(fill="x")

        tk.Label(
            topo, text="🤖 DevChat AI",
            font=("Segoe UI", 17, "bold"),
            bg=c["painel"], fg=c["texto"]
        ).pack(side="left")

        tk.Button(
            topo, text="🌗 Alternar Tema",
            command=self.alternar_tema,
            bg=c["botao"], fg="white",
            relief="flat", cursor="hand2"
        ).pack(side="right", padx=(8, 0), ipady=5, ipadx=5)

        tk.Button(
            topo, text="Limpar",
            command=self.limpar_conversa,
            bg=c["bot"], fg=c["texto"],
            relief="flat", cursor="hand2"
        ).pack(side="right", padx=5, ipady=5, ipadx=5)

        # Área com rolagem
        area = tk.Frame(self.root, bg=c["fundo"])
        area.pack(fill="both", expand=True, padx=18, pady=15)

        self.canvas = tk.Canvas(
            area, bg=c["fundo"], highlightthickness=0
        )
        barra = tk.Scrollbar(
            area, orient="vertical", command=self.canvas.yview
        )
        self.lista_mensagens = tk.Frame(
            self.canvas, bg=c["fundo"]
        )

        self.janela_canvas = self.canvas.create_window(
            (0, 0), window=self.lista_mensagens, anchor="nw"
        )

        self.lista_mensagens.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(
                self.janela_canvas, width=e.width
            )
        )

        self.canvas.configure(yscrollcommand=barra.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")

        # Campo de envio
        rodape = tk.Frame(
            self.root, bg=c["painel"], padx=15, pady=14
        )
        rodape.pack(fill="x")

        self.entrada = tk.Entry(
            rodape, font=("Segoe UI", 12),
            bg=c["entrada"], fg=c["texto"],
            insertbackground=c["texto"], relief="flat"
        )
        self.entrada.pack(
            side="left", fill="x", expand=True,
            ipady=11, padx=(0, 10)
        )
        self.entrada.bind("<Return>", self.enviar_tecla)

        self.botao_enviar = tk.Button(
            rodape, text="Enviar",
            command=self.enviar_mensagem,
            bg=c["botao"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", cursor="hand2"
        )
        self.botao_enviar.pack(side="right", ipady=7, ipadx=12)

        if not self.historico:
            self.adicionar_mensagem(
                "DevChat AI",
                "🤖",
                "Olá! Sou o DevChat AI, seu assistente de TI. "
                "Pergunte sobre Python, HTML, CSS, JavaScript, SQL, "
                "Docker ou redes de computadores.",
                False
            )
        else:
            for nome, icone, texto, eh_usuario in self.historico:
                self.exibir_mensagem(nome, icone, texto, eh_usuario)

        self.entrada.focus_set()

    def adicionar_mensagem(self, nome, icone, texto, eh_usuario):
        self.historico.append((nome, icone, texto, eh_usuario))
        self.exibir_mensagem(nome, icone, texto, eh_usuario)

    def exibir_mensagem(self, nome, icone, texto, eh_usuario):
        c = self.cores()

        linha = tk.Frame(self.lista_mensagens, bg=c["fundo"])
        linha.pack(fill="x", pady=7)

        cor_mensagem = c["usuario"] if eh_usuario else c["bot"]
        lado = "right" if eh_usuario else "left"

        cartao = tk.Frame(
            linha, bg=cor_mensagem, padx=13, pady=10
        )
        cartao.pack(side=lado, anchor="e" if eh_usuario else "w")

        tk.Label(
            cartao, text=f"{icone}  {nome}",
            font=("Segoe UI", 10, "bold"),
            bg=cor_mensagem, fg=c["texto"], anchor="w"
        ).pack(fill="x", pady=(0, 5))

        tk.Label(
            cartao, text=texto,
            font=("Segoe UI", 11),
            bg=cor_mensagem, fg=c["texto"],
            justify="left", anchor="w",
            wraplength=560
        ).pack(fill="x")

        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def enviar_tecla(self, event):
        self.enviar_mensagem()
        return "break"

    def enviar_mensagem(self):
        mensagem = self.entrada.get().strip()

        if not mensagem:
            return

        self.entrada.delete(0, "end")
        self.adicionar_mensagem(
            NOME_USUARIO, "👤", mensagem, True
        )

        self.botao_enviar.config(state="disabled", text="Pensando...")

        # Simula o raciocínio sem bloquear a janela
        self.root.after(900, lambda: self.responder_chat(mensagem))

    def responder_chat(self, mensagem):
        resposta = responder(mensagem)

        self.adicionar_mensagem(
            NOME_BOT, "🤖", resposta, False
        )

        self.botao_enviar.config(state="normal", text="Enviar")
        self.entrada.focus_set()

    def limpar_conversa(self):
        self.historico.clear()
        self.tela_chat()

    def alternar_tema(self):
        self.tema_escuro = not self.tema_escuro
        self.tela_chat()


if __name__ == "__main__":
    janela = tk.Tk()
    app = DevChatApp(janela)
    janela.mainloop()
