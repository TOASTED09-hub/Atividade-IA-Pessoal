
import random


def responder(mensagem):
    texto = mensagem.lower().strip()

    if any(p in texto for p in ["olá", "ola", "oi", "bom dia", "boa tarde"]):
        return random.choice([
            "Olá! Sou o DevChat AI. Como posso ajudar você com TI?",
            "Oi! Vamos estudar tecnologia? Pode mandar sua dúvida."
        ])

    elif "python" in texto:
        return (
            "Python é uma linguagem de programação conhecida pela "
            "sintaxe simples. É utilizada em automação, desenvolvimento "
            "web, análise de dados e inteligência artificial.\n\n"
            "Exemplo:\n"
            "nome = 'Maria'\n"
            "print('Olá,', nome)"
        )

    elif "html" in texto:
        return (
            "HTML é uma linguagem de marcação usada para estruturar "
            "páginas web. Com ela, você cria títulos, parágrafos, "
            "links, imagens e formulários.\n\n"
            "Exemplo: <h1>Meu site</h1>"
        )

    elif "css" in texto:
        return (
            "CSS é usado para definir a aparência de páginas HTML, "
            "incluindo cores, fontes, espaçamentos e layouts.\n\n"
            "Exemplo:\n"
            "h1 {\n"
            "    color: blue;\n"
            "}"
        )

    elif "javascript" in texto or "js" == texto:
        return (
            "JavaScript permite adicionar interatividade às páginas web, "
            "como menus, validações e atualizações de conteúdo.\n\n"
            "Exemplo:\n"
            "console.log('Olá, mundo!');"
        )

    elif "sql" in texto or "banco de dados" in texto:
        return (
            "SQL é uma linguagem usada para consultar e manipular "
            "bancos de dados relacionais.\n\n"
            "Exemplo:\n"
            "SELECT * FROM clientes;\n\n"
            "Esse comando consulta todos os registros da tabela clientes."
        )

    elif "docker" in texto:
        return (
            "Docker permite executar aplicações em containers, "
            "que reúnem a aplicação e suas dependências.\n\n"
            "Exemplo:\n"
            "docker ps\n\n"
            "Esse comando lista os containers em execução."
        )

    elif "rede" in texto or "internet" in texto:
        return (
            "Uma rede de computadores conecta dispositivos para "
            "compartilhar dados e recursos. Conceitos importantes "
            "incluem IP, DNS, roteadores e protocolos como TCP/IP."
        )

    elif "python" in texto or "programação" in texto:
        return (
            "Programação é o processo de criar instruções para um "
            "computador executar tarefas. Você pode começar estudando "
            "variáveis, condicionais, laços de repetição e funções."
        )

    elif "obrigado" in texto or "obrigada" in texto:
        return "Por nada! Estou aqui para ajudar nos seus estudos de TI."

    elif "ajuda" in texto or "assuntos" in texto:
        return (
            "Posso ajudar com estes assuntos:\n\n"
            "• Python e lógica de programação\n"
            "• HTML, CSS e JavaScript\n"
            "• SQL e bancos de dados\n"
            "• Docker e containers\n"
            "• Redes de computadores\n\n"
            "Faça uma pergunta sobre qualquer um desses temas!"
        )

    else:
        return (
            "Ainda não tenho uma resposta específica para essa pergunta "
            "na minha base local.\n\n"
            "Tente perguntar sobre Python, HTML, CSS, JavaScript, SQL, "
            "Docker ou redes de computadores."
        )
